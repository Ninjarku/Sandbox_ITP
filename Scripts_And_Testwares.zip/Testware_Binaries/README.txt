To use al-khaser Binaries, you will need to install the required DLLs on machines before running it, same for wmi-mal
The password to all files are infected

Copy the req_dll contents into C:\Windows\System32
and skip all that are already there.

